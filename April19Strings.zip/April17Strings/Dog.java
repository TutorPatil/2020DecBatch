package com.corejava.strings;

public class Dog {
	
	String name;
	int age;
	
	public void eat()
	{
		System.out.println("The dog of the age "+age +"of the name "+name +" is eating");
	}
	
	public String toString()
	{
		return "Dogs To StirngMethod";
	}
	

}
