package com.actitime.base;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.google.common.io.Files;

public class BaseClass {
	
	public static WebDriver driver = null;
	
	public static void launchApplication() throws IOException {
		
		String browser = getConfigData("browser");		
		String url = getConfigData("url");
		
		if ( browser.equalsIgnoreCase("chrome"))
		{
			System.setProperty("webdriver.chrome.driver", "./tools/chromedriver.exe");
			driver = new ChromeDriver();
		
		}
		else if(browser.equalsIgnoreCase("firefox"))
		{
			System.setProperty("webdriver.gecko.driver", "./tools/geckodriver.exe");
			driver = new FirefoxDriver();
		}
		driver.get(url);		
		driver.manage().window().maximize();
		
		// implicit wait		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	
	public static String getConfigData(String propName) throws IOException
	{
		String propValue = null;
		
		File f = new File("./data/config.properties");
		InputStream fio = new FileInputStream(f);		
		Properties prop = new Properties();
		prop.load(fio);		
		propValue = prop.getProperty(propName);
		
		return propValue;
	}
	
	
	public static String getLocatorDataFromExcel(String pageName, String elementName) throws IOException
	{
		String locator = "";
		
		File f= new File("./data/locatordata.xlsx");		
		FileInputStream fio = new FileInputStream(f);
		
		XSSFWorkbook wb = new XSSFWorkbook(fio);
		XSSFSheet ws = wb.getSheet("Sheet1");
		
		int rows = ws.getLastRowNum();
		
		for(int x=1; x<=rows;x++)
		{
			String page = ws.getRow(x).getCell(0).getStringCellValue();
			String element = ws.getRow(x).getCell(1).getStringCellValue();
			
			if (page.equalsIgnoreCase(pageName) && (element.equalsIgnoreCase(elementName)))
			{
				locator = ws.getRow(x).getCell(2).getStringCellValue();
				break;
			}
				
		}		
		wb.close();
		
		return locator;
		
		
	}
	
	
	public static String getTestDataFromExcel(String pageName, String elementName) throws IOException
	{
		String testdata = "";
		
		File f= new File("./data/testdata.xlsx");		
		FileInputStream fio = new FileInputStream(f);
		
		XSSFWorkbook wb = new XSSFWorkbook(fio);
		XSSFSheet ws = wb.getSheet("Sheet1");
		
		int rows = ws.getLastRowNum();
		
		for(int x=1; x<=rows;x++)
		{
			String page = ws.getRow(x).getCell(0).getStringCellValue();
			String element = ws.getRow(x).getCell(1).getStringCellValue();
			
			if (page.equalsIgnoreCase(pageName) && (element.equalsIgnoreCase(elementName)))
			{
				testdata = ws.getRow(x).getCell(2).getStringCellValue();
				break;
			}
				
		}		
		wb.close();
		
		return testdata;
		
		
	}
	
	
	public static void  writeResultsToFile(String testCaseName, String status) throws IOException
	{
		File f = new File("./results/results.txt");
		FileWriter fw = new FileWriter(f,true);
		
		fw.write(testCaseName+"-----"+status+" \n");
		
		fw.flush();
		fw.close();
		
		
	}
	
	
	public static void capturescreenShot(String fileName) throws IOException
	{
		
		TakesScreenshot ts = (TakesScreenshot)driver;		
		File src = ts.getScreenshotAs(OutputType.FILE);
		File dest = new File("./results/screenshots/"+fileName+".png");
		Files.copy(src, dest);
		
		
		
	}
	
	public static void closeBrowser()
	{
		driver.quit();
	}
	
	

	
	
	
	

}
