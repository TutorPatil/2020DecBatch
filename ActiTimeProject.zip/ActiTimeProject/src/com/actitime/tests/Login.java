package com.actitime.tests;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.TakesScreenshot;

import com.actitime.base.BaseClass;

public class Login extends BaseClass{
	
	
	
	public static void Login_001() throws IOException
	{
		
		try {			
		
		launchApplication();
		
		driver.findElement(By.xpath(getLocatorDataFromExcel("Login","UserName_EditBox"))).
		sendKeys(getTestDataFromExcel("Login", "UserName_EditBox"));
		
		driver.findElement(By.xpath(getLocatorDataFromExcel("Login","Password_EditBox"))).
		sendKeys(getTestDataFromExcel("Login", "Password_EditBox"));
		
		driver.findElement(By.xpath(getLocatorDataFromExcel("Login","Login_Button"))).click();
		
		boolean result = driver.findElement(By.xpath(getLocatorDataFromExcel("Home","Logout_Link"))).isDisplayed();
		
		if(result)
		{
			writeResultsToFile("Login_001", "Pass");
		}
		else
		{
			writeResultsToFile("Login_001", "Fail");
			capturescreenShot("Login_001");
		}
		
		}catch (Exception e) {
			
			e.printStackTrace();
			writeResultsToFile("Login_001", "Fail");
			capturescreenShot("Login_001");
		}
		
		closeBrowser();
		
		
		
	}
	
	

}
