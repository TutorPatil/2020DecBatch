package com.actitime.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.actitime.base.BaseClass;
import com.actitime.pages.HomePage;
import com.actitime.pages.LoginPage;

public class LoginTest extends BaseClass{

	public static void main(String[] args) {
		
		
	}
	
	@Test
	public static void login_001()
	{
		LoginPage login = new LoginPage(driver);
		login.setUserName("admin");
		login.setPassword("manager");
		HomePage home = login.clickOkButton(driver);	
		
		boolean result = home.checkLogoutLinkDisplay();
		
		Assert.assertTrue(result, "Login  Test case Failed....");
		
		
	}

}
