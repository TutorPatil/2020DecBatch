package com.actitime.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
	
	private WebDriver driver;
	
	@FindBy(xpath ="//input[@name='username']")
	private WebElement userName;
	
	@FindBy(name = "pwd")
	private WebElement password;
	

	@FindBy(id="loginButton")
	private WebElement okBtn;
	
	@FindBy(xpath="//span[text()='Username or Password is invalid. Please try again.']")
	private WebElement errorMsg;
	
	public void setUserName(String userdata)
	{
		userName.sendKeys(userdata);
	}
	
	public void setPassword(String pwd)
	{
		password.sendKeys(pwd);
	}
	
	public HomePage clickOkButton(WebDriver driver)
	{
		okBtn.click();
		HomePage home = new HomePage(driver);
		return home;
	}
	
	//constructor	
	public  LoginPage(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
	

}
