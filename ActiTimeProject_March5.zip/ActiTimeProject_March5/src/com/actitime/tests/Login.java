package com.actitime.tests;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.TakesScreenshot;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.actitime.base.BaseClass;
import com.actitime.utils.CommonLibrary;

public class Login extends BaseClass{
	
	
	@Test
	public static void login_001() throws IOException
	{		
		
		CommonLibrary.launchAndLoginToActitime();	
		boolean result = getWebElementFromPageAndElementNames("Home","Logout_Link").isDisplayed();
	
		//Assert.assertFalse(result, "Login_001 Failed");
		Assert.assertTrue(result, "Login_001 Failed");
		writeResultsToFile("Login_001", "Pass");	
		
		/*
		// Assert Equals
			int count = 10;		
			Assert.assertEquals(11, count,"The count of employes did not match");
		*/
		
		
	}
		
	//@Test(dependsOnMethods = { "login_001" })
	@Test
	public static void login_002() throws IOException
	{
		
		try {
			
		String username = getTestDataFromExcel("Login", "InvalidUserName");
		String passowrd = getTestDataFromExcel("Login", "InvalildPassword");
		
		CommonLibrary.launchAndLoginToActitime(username,passowrd);
		
		boolean result = getWebElementFromPageAndElementNames("Login","Error_Message").isDisplayed();
		
		if(result)
		{
			writeResultsToFile("Login_002", "Pass");
		}
		else
		{
			writeResultsToFile("Login_002", "Fail");
			capturescreenShot("Login_002");
		}
		
		}catch (Exception e) {
			
			e.printStackTrace();
			writeResultsToFile("Login_002", "Fail");
			capturescreenShot("Login_002");
		}
		
		closeBrowser();
		
		
		
	}
	/*
	
	@Test
	public static void login_001() throws IOException
	{		
		boolean result = false;
		CommonLibrary.launchAndLoginToActitime();	
		try {
			
			result = getWebElementFromPageAndElementNames("Home","Logout_Link").isDisplayed();
		}
		catch (Exception e) {
			e.printStackTrace();
		}	
		
		Assert.assertTrue(result, "Login_001 Failed");
		writeResultsToFile("Login_001", "Pass");	
		
		
		
	}
	*/
	

}
