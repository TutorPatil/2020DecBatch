package com.actitime.tests;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.TakesScreenshot;

import com.actitime.base.BaseClass;
import com.actitime.utils.CommonLibrary;

public class Login extends BaseClass{
	
	
	
	public static void Login_001() throws IOException
	{
		
		try {
		
		CommonLibrary.launchAndLoginToActitime();		
		boolean result = getWebElementFromPageAndElementNames("Home","Logout_Link").isDisplayed();
		
		if(result)
		{
			writeResultsToFile("Login_001", "Pass");
		}
		else
		{
			writeResultsToFile("Login_001", "Fail");
			capturescreenShot("Login_001");
		}
		
		}catch (Exception e) {			
			e.printStackTrace();
			writeResultsToFile("Login_001", "Fail");
			capturescreenShot("Login_001");
		}
		
		closeBrowser();	
		
	}
		
	
	public static void Login_002() throws IOException
	{
		
		try {
			
		String username = getTestDataFromExcel("Login", "InvalidUserName");
		String passowrd = getTestDataFromExcel("Login", "InvalildPassword");
		
		CommonLibrary.launchAndLoginToActitime(username,passowrd);
		
		boolean result = getWebElementFromPageAndElementNames("Login","Error_Message").isDisplayed();
		
		if(result)
		{
			writeResultsToFile("Login_002", "Pass");
		}
		else
		{
			writeResultsToFile("Login_002", "Fail");
			capturescreenShot("Login_002");
		}
		
		}catch (Exception e) {
			
			e.printStackTrace();
			writeResultsToFile("Login_002", "Fail");
			capturescreenShot("Login_002");
		}
		
		closeBrowser();
		
		
		
	}
	

}
