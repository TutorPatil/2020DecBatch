package com.actitime.tests;

import java.io.IOException;

public class Runner {

	public static void main(String[] args) throws IOException {
		
		try {
			Login.Login_001();
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		try {
			Login.Login_002();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

}
