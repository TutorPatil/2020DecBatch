package com.actitime.utils;

import java.io.IOException;

import com.actitime.base.BaseClass;

public class CommonLibrary extends BaseClass{
	
	
	public static void launchAndLoginToActitime() throws IOException
	{
		
		launchApplication();
		
		getWebElementFromPageAndElementNames("Login","UserName_EditBox").
		sendKeys(getTestDataFromExcel("Login", "ValidUserName"));	
		
		
		getWebElementFromPageAndElementNames("Login","Password_EditBox").
		sendKeys(getTestDataFromExcel("Login", "ValidPassword"));
		
		getWebElementFromPageAndElementNames("Login","Login_Button").click();
		
		
	}
	
	
	public static void launchAndLoginToActitime(String userName, String password) throws IOException
	{
		
		launchApplication();
		
		getWebElementFromPageAndElementNames("Login","UserName_EditBox").
		sendKeys(userName);	
		
		
		getWebElementFromPageAndElementNames("Login","Password_EditBox").
		sendKeys(password);
		
		getWebElementFromPageAndElementNames("Login","Login_Button").click();
		
		
	}
	
	

}
